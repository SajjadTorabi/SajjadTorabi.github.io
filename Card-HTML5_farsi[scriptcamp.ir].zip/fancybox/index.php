<Center><a href="http://www.scriptcamp.ir/">scriptcamp</a><Center>
<META http-equiv=refresh content="1; url=http://www.scriptcamp.ir/">